from __future__ import annotations

import csv
import json
import os
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, Mapping

import numpy as np
import torch

from .agent import DDPGAgent
from .assignment_diagnostics import (
    ASSIGNMENT_DIAGNOSTIC_FIELDS,
    COUNT_METRICS,
    TRACKED_METRICS,
    AssignmentDiagnosticsWindow,
)
from .config import COUNT_MATCHED_ASSIGNMENT_MODES, LiteConfig
from .envs import FetchGoalEnv
from .envs_maniskill import ManiSkillPickCubeGoalEnv, ManiSkillPushTGoalEnv, UnitreeAppleGoalEnv
from .io_utils import (
    MetricsCSVWriter,
    MetricsJSONLWriter,
    env_thread_hint,
    make_run_dir,
    select_device,
    set_all_seeds,
    setup_logger,
    write_json,
)
from .replay import HERReplayBuffer
from .task_fetch_pick_and_place import FetchPickAndPlaceTaskSpec
from .task_fetch_push import FetchPushTaskSpec
from .task_fetch_slide import FetchSlideTaskSpec
from .task_pick_cube import PickCubeTaskSpec
from .task_push_t import PushTTaskSpec
from .task_unitree_apple import UnitreeAppleTaskSpec
from .weights import GapStats, LiteWeightComputer


def _checkpoint_path(run_dir: Path) -> Path:
    return run_dir / "checkpoint.pt"


def _best_checkpoint_path(run_dir: Path) -> Path:
    return run_dir / "best_checkpoint.pt"


def _step_checkpoint_path(run_dir: Path, step: int) -> Path:
    return run_dir / f"checkpoint_step_{int(step)}.pt"


def save_checkpoint(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, path)


def save_checkpoint_atomic(path: Path, payload: Dict[str, Any]) -> None:
    """Write a checkpoint through an fsynced temporary and atomic replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.resume_canonicalize.{os.getpid()}.tmp"
    )
    if temporary.exists():
        raise RuntimeError(
            f"stale resume checkpoint temporary exists: {temporary}"
        )
    try:
        with temporary.open("xb") as handle:
            torch.save(payload, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_checkpoint(path: Path) -> Dict[str, Any]:
    return torch.load(path, map_location="cpu", weights_only=False)


def validate_resume_checkpoint_config(
    config: LiteConfig,
    payload: Mapping[str, Any],
) -> None:
    """Reject checkpoints from any scientifically or operationally different run."""
    checkpoint_config = payload.get("config")
    if not isinstance(checkpoint_config, Mapping):
        raise RuntimeError("resume checkpoint is missing its resolved config")
    expected = dict(config.as_dict())
    observed = dict(checkpoint_config)
    # These two fields describe the act of loading a checkpoint, not the
    # training trajectory stored inside it. Every other resolved field,
    # including run identity, budget, method, query/assignment modes, device,
    # and all seeds, must match exactly.
    for operational_key in ("resume", "resume_path"):
        expected.pop(operational_key, None)
        observed.pop(operational_key, None)
    if observed != expected:
        differences = sorted(
            key
            for key in set(observed) | set(expected)
            if observed.get(key) != expected.get(key)
        )
        raise RuntimeError(
            "resume checkpoint config differs from the frozen run config: "
            + ", ".join(differences)
        )


def _validate_finite_checkpoint_tree(value: Any, path: str) -> None:
    if isinstance(value, Mapping):
        for key, child in value.items():
            _validate_finite_checkpoint_tree(child, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            _validate_finite_checkpoint_tree(child, f"{path}[{index}]")
    elif isinstance(value, (float, np.floating)) and not np.isfinite(value):
        raise RuntimeError(f"non-finite count-matched checkpoint state at {path}")


def restore_assignment_checkpoint_state(
    config: LiteConfig,
    payload: Dict[str, Any],
    assignment_rng: np.random.Generator,
    assignment_diagnostics: AssignmentDiagnosticsWindow,
) -> None:
    """Restore count-matched state; never silently reseed a control resume."""
    count_matched = (
        config.support_assignment_mode in COUNT_MATCHED_ASSIGNMENT_MODES
    )
    if "assignment_rng_state" in payload:
        assignment_rng.bit_generator.state = payload["assignment_rng_state"]
    elif count_matched:
        raise RuntimeError("control checkpoint is missing assignment_rng_state")
    if "assignment_diagnostics_state" in payload:
        if count_matched:
            _validate_finite_checkpoint_tree(
                payload["assignment_diagnostics_state"],
                "assignment_diagnostics_state",
            )
        assignment_diagnostics.load_state_dict(
            payload["assignment_diagnostics_state"]
        )
    elif count_matched:
        raise RuntimeError(
            "control checkpoint is missing assignment_diagnostics_state"
        )


def restore_training_progress(
    payload: Dict[str, Any],
    last_loss: Dict[str, float],
    last_lite: Dict[str, float],
) -> tuple[
    int,
    int,
    int,
    float,
    Dict[str, float],
    list[tuple[int, float]],
]:
    """Restore completed-transition progress and observable training state."""
    start_step = int(payload["global_step"])
    episode_idx = int(payload["episode_idx"])
    total_updates = int(payload.get("total_updates", 0))
    last_loss.update(
        {str(key): float(value) for key, value in dict(payload.get("last_loss", {})).items()}
    )
    last_lite.update(
        {str(key): float(value) for key, value in dict(payload.get("last_lite", {})).items()}
    )
    last_her_ratio = float(payload.get("last_her_ratio", 0.0))
    last_eval_metrics = {
        str(key): float(value)
        for key, value in dict(payload.get("last_eval_metrics", {})).items()
    }
    eval_history_env = [
        (int(step), float(value))
        for step, value in payload.get("eval_history_env", [])
    ]
    return (
        start_step,
        episode_idx,
        total_updates,
        last_her_ratio,
        last_eval_metrics,
        eval_history_env,
    )


def _complete_utf8_lines(path: Path) -> tuple[list[str], bool]:
    """Read newline-terminated records, dropping only a trailing partial record."""
    if not path.exists():
        return [], False
    raw_lines = path.read_bytes().splitlines(keepends=True)
    dropped_partial = False
    if raw_lines and not raw_lines[-1].endswith(b"\n"):
        raw_lines.pop()
        dropped_partial = True
    lines: list[str] = []
    for index, raw_line in enumerate(raw_lines, start=1):
        try:
            lines.append(raw_line.decode("utf-8"))
        except UnicodeDecodeError as exc:
            raise RuntimeError(
                f"{path}: invalid UTF-8 in complete record {index}"
            ) from exc
    return lines, dropped_partial


def _atomic_rewrite_lines(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.resume_rollback.{os.getpid()}.tmp"
    )
    if temporary.exists():
        raise RuntimeError(f"stale resume rollback temporary exists: {temporary}")
    try:
        with temporary.open("x", encoding="utf-8", newline="") as handle:
            handle.writelines(lines)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _csv_record(line: str, path: Path, line_number: int) -> list[str]:
    try:
        rows = list(csv.reader([line], strict=True))
    except csv.Error as exc:
        raise RuntimeError(
            f"{path}: malformed complete CSV record at line {line_number}"
        ) from exc
    if len(rows) != 1:
        raise RuntimeError(
            f"{path}: expected one CSV record at line {line_number}"
        )
    return rows[0]


def _required_int(value: Any, *, path: Path, field: str, row: int) -> int:
    text = str(value).strip()
    try:
        numeric = Decimal(text)
    except (InvalidOperation, ValueError) as exc:
        raise RuntimeError(
            f"{path}: invalid integer {field}={value!r} at data row {row}"
        ) from exc
    if not numeric.is_finite() or numeric != numeric.to_integral_value():
        raise RuntimeError(
            f"{path}: invalid integer {field}={value!r} at data row {row}"
        )
    return int(numeric)


def _rollback_metrics_outputs(
    run_dir: Path,
    payload: Dict[str, Any],
    expected_fields: list[str],
) -> Dict[str, int]:
    boundary = int(payload["global_step"])
    expected_episode_count = int(payload["episode_idx"])
    expected_eval_history = [
        (int(step), float(value))
        for step, value in payload.get("eval_history_env", [])
    ]
    csv_path = run_dir / "metrics.csv"
    jsonl_path = run_dir / "metrics.jsonl"
    csv_lines, csv_partial = _complete_utf8_lines(csv_path)
    jsonl_lines, jsonl_partial = _complete_utf8_lines(jsonl_path)
    if not csv_lines or not jsonl_lines:
        raise RuntimeError(
            "resume checkpoint has no complete metrics.csv/metrics.jsonl prefix"
        )

    header = _csv_record(csv_lines[0], csv_path, 1)
    if header != expected_fields:
        raise RuntimeError(
            f"{csv_path}: header differs from the frozen writer schema"
        )
    csv_retained_lines = [csv_lines[0]]
    csv_records: list[tuple[str, int, int]] = []
    eval_values: list[tuple[int, float]] = []
    saw_post_checkpoint = False
    previous_retained_step = -1
    for row_index, line in enumerate(csv_lines[1:], start=1):
        values = _csv_record(line, csv_path, row_index + 1)
        if len(values) != len(header):
            raise RuntimeError(
                f"{csv_path}: column count mismatch at data row {row_index}"
            )
        row = dict(zip(header, values))
        step = _required_int(
            row.get("step", ""), path=csv_path, field="step", row=row_index
        )
        episode = _required_int(
            row.get("episode", ""),
            path=csv_path,
            field="episode",
            row=row_index,
        )
        if step <= 0:
            raise RuntimeError(
                f"{csv_path}: non-positive step at data row {row_index}"
            )
        record_type = (
            "eval" if str(row.get("eval/return_mean", "")).strip() else "episode"
        )
        if step <= boundary:
            if saw_post_checkpoint:
                raise RuntimeError(
                    f"{csv_path}: pre-checkpoint row follows a post-checkpoint row"
                )
            if step < previous_retained_step:
                raise RuntimeError(
                    f"{csv_path}: non-monotonic retained step at data row "
                    f"{row_index}"
                )
            previous_retained_step = step
            csv_retained_lines.append(line)
            csv_records.append((record_type, step, episode))
            if record_type == "eval":
                try:
                    eval_value = float(row["eval/env_success_mean"])
                except (KeyError, ValueError) as exc:
                    raise RuntimeError(
                        f"{csv_path}: invalid eval value at data row {row_index}"
                    ) from exc
                if not np.isfinite(eval_value):
                    raise RuntimeError(
                        f"{csv_path}: non-finite eval value at data row {row_index}"
                    )
                eval_values.append((step, eval_value))
        else:
            saw_post_checkpoint = True

    episode_rows = [
        episode for record_type, _step, episode in csv_records
        if record_type == "episode"
    ]
    if episode_rows != list(range(1, expected_episode_count + 1)):
        raise RuntimeError(
            f"{csv_path}: retained episode rows are not exactly 1..{expected_episode_count}"
        )
    if len(eval_values) != len(expected_eval_history):
        raise RuntimeError(
            f"{csv_path}: retained eval count differs from checkpoint history"
        )
    for observed, expected in zip(eval_values, expected_eval_history):
        if observed[0] != expected[0] or not np.isclose(
            observed[1], expected[1], rtol=0.0, atol=1e-12
        ):
            raise RuntimeError(
                f"{csv_path}: retained eval history differs from checkpoint"
            )

    jsonl_retained_lines: list[str] = []
    jsonl_records: list[tuple[str, int, int]] = []
    saw_post_checkpoint = False
    previous_retained_step = -1
    for row_index, line in enumerate(jsonl_lines, start=1):
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"{jsonl_path}: malformed complete JSON record at line {row_index}"
            ) from exc
        if not isinstance(row, dict) or row.get("type") not in {"episode", "eval"}:
            raise RuntimeError(
                f"{jsonl_path}: invalid record type at line {row_index}"
            )
        step = _required_int(
            row.get("step", ""), path=jsonl_path, field="step", row=row_index
        )
        episode = _required_int(
            row.get("episode", ""),
            path=jsonl_path,
            field="episode",
            row=row_index,
        )
        if step <= 0:
            raise RuntimeError(
                f"{jsonl_path}: non-positive step at line {row_index}"
            )
        if step <= boundary:
            if saw_post_checkpoint:
                raise RuntimeError(
                    f"{jsonl_path}: pre-checkpoint record follows post-checkpoint data"
                )
            if step < previous_retained_step:
                raise RuntimeError(
                    f"{jsonl_path}: non-monotonic retained step at line "
                    f"{row_index}"
                )
            previous_retained_step = step
            jsonl_retained_lines.append(line)
            jsonl_records.append((str(row["type"]), step, episode))
        else:
            saw_post_checkpoint = True
    if jsonl_records != csv_records:
        raise RuntimeError(
            "retained metrics.csv and metrics.jsonl record sequences differ"
        )

    _atomic_rewrite_lines(csv_path, csv_retained_lines)
    _atomic_rewrite_lines(jsonl_path, jsonl_retained_lines)
    return {
        "metrics_rows": len(csv_records),
        "eval_rows": len(eval_values),
        "dropped_csv_partial": int(csv_partial),
        "dropped_jsonl_partial": int(jsonl_partial),
    }


def _rollback_assignment_diagnostics(
    run_dir: Path,
    payload: Dict[str, Any],
    window_size: int,
) -> Dict[str, int]:
    path = run_dir / "assignment_diagnostics_1000.csv"
    state = dict(payload.get("assignment_diagnostics_state", {}))
    if not state:
        raise RuntimeError(
            "count-matched resume checkpoint lacks assignment_diagnostics_state"
        )
    expected_window_index = int(state["window_index"])
    last_update = int(state["last_update"])
    pending_count = int(state["count"])
    if (
        expected_window_index < 0
        or last_update < 0
        or pending_count < 0
        or pending_count >= int(window_size)
        or pending_count > last_update
    ):
        raise RuntimeError("invalid assignment diagnostic checkpoint state")
    emitted_update_boundary = last_update - pending_count

    lines, dropped_partial = _complete_utf8_lines(path)
    if not lines:
        if expected_window_index == 0:
            if path.exists():
                _atomic_rewrite_lines(path, [])
            return {
                "assignment_rows": 0,
                "assignment_emitted_update_boundary": 0,
                "dropped_assignment_partial": int(dropped_partial),
            }
        raise RuntimeError(
            f"{path}: checkpoint expects emitted diagnostic windows but file is empty"
        )
    header = _csv_record(lines[0], path, 1)
    if header != ASSIGNMENT_DIAGNOSTIC_FIELDS:
        raise RuntimeError(f"{path}: header differs from assignment schema")

    retained_lines = [lines[0]]
    retained_rows: list[Dict[str, str]] = []
    saw_post_checkpoint = False
    for row_index, line in enumerate(lines[1:], start=1):
        values = _csv_record(line, path, row_index + 1)
        if len(values) != len(header):
            raise RuntimeError(
                f"{path}: column count mismatch at data row {row_index}"
            )
        row = dict(zip(header, values))
        index = _required_int(
            row["window_index"], path=path, field="window_index", row=row_index
        )
        if index <= expected_window_index:
            if saw_post_checkpoint:
                raise RuntimeError(
                    f"{path}: retained window follows a post-checkpoint window"
                )
            retained_lines.append(line)
            retained_rows.append(row)
        else:
            saw_post_checkpoint = True

    if len(retained_rows) != expected_window_index:
        raise RuntimeError(
            f"{path}: retained window count differs from checkpoint"
        )
    previous_end = 0
    zero_count_fields = (
        "exact_k_mismatch_count",
        "raw_histogram_mismatch_count",
        "normalized_histogram_mismatch_count",
        "invariant_failure_count",
    )
    for row_index, row in enumerate(retained_rows, start=1):
        index = _required_int(
            row["window_index"], path=path, field="window_index", row=row_index
        )
        update_start = _required_int(
            row["update_start"], path=path, field="update_start", row=row_index
        )
        update_end = _required_int(
            row["update_end"], path=path, field="update_end", row=row_index
        )
        updates = _required_int(
            row["updates"], path=path, field="updates", row=row_index
        )
        complete = _required_int(
            row["complete_window"],
            path=path,
            field="complete_window",
            row=row_index,
        )
        if index != row_index or update_start != previous_end + 1:
            raise RuntimeError(
                f"{path}: non-contiguous diagnostic window at row {row_index}"
            )
        if updates <= 0 or update_end - update_start + 1 != updates:
            raise RuntimeError(
                f"{path}: invalid diagnostic update range at row {row_index}"
            )
        expected_complete = int(updates == int(window_size))
        if complete != expected_complete:
            raise RuntimeError(
                f"{path}: complete_window mismatch at row {row_index}"
            )
        for field in zero_count_fields:
            if _required_int(
                row[field], path=path, field=field, row=row_index
            ) != 0:
                raise RuntimeError(
                    f"{path}: invariant failure recorded at row {row_index}"
                )
        previous_end = update_end
    if previous_end != emitted_update_boundary:
        raise RuntimeError(
            f"{path}: emitted update boundary {previous_end} differs from "
            f"checkpoint {emitted_update_boundary}"
        )
    _atomic_rewrite_lines(path, retained_lines)
    return {
        "assignment_rows": len(retained_rows),
        "assignment_emitted_update_boundary": emitted_update_boundary,
        "dropped_assignment_partial": int(dropped_partial),
    }


def _quarantine_path(path: Path, quarantine_dir: Path) -> Path:
    quarantine_dir.mkdir(parents=True, exist_ok=True)
    candidate = quarantine_dir / path.name
    counter = 1
    while candidate.exists():
        candidate = quarantine_dir / f"{path.name}.{counter}"
        counter += 1
    os.replace(path, candidate)
    return candidate


def _files_identical(left: Path, right: Path) -> bool:
    if left.stat().st_size != right.stat().st_size:
        return False
    with left.open("rb") as left_handle, right.open("rb") as right_handle:
        while True:
            left_chunk = left_handle.read(1024 * 1024)
            right_chunk = right_handle.read(1024 * 1024)
            if left_chunk != right_chunk:
                return False
            if not left_chunk:
                return True


def canonicalize_resume_checkpoint(
    run_dir: Path,
    selected_checkpoint_path: Path,
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    """Make a custom resume payload authoritative for the next default resume."""
    selected = selected_checkpoint_path.resolve()
    canonical = _checkpoint_path(run_dir).resolve()
    try:
        same_file = canonical.exists() and os.path.samefile(selected, canonical)
    except OSError:
        same_file = selected == canonical
    if same_file:
        return {
            "canonical_checkpoint_rewritten": 0,
            "quarantined_canonical_checkpoint": "",
        }
    if not selected.is_file():
        raise FileNotFoundError(
            f"selected resume checkpoint disappeared: {selected}"
        )

    quarantined = ""
    if canonical.exists():
        if _files_identical(canonical, selected):
            return {
                "canonical_checkpoint_rewritten": 0,
                "quarantined_canonical_checkpoint": "",
            }
        quarantined = str(
            _quarantine_path(
                canonical,
                run_dir / "resume_rollback_quarantine",
            )
        )
    save_checkpoint_atomic(canonical, payload)
    if not canonical.is_file() or canonical.stat().st_size <= 0:
        raise RuntimeError("canonical resume checkpoint atomic save failed")
    return {
        "canonical_checkpoint_rewritten": 1,
        "quarantined_canonical_checkpoint": quarantined,
    }


def _quarantine_stale_checkpoint_evidence(
    run_dir: Path,
    payload: Dict[str, Any],
) -> list[str]:
    boundary = int(payload["global_step"])
    quarantine_dir = run_dir / "resume_rollback_quarantine"
    quarantined: list[str] = []
    best_json = run_dir / "best_checkpoint.json"
    best_pt = run_dir / "best_checkpoint.pt"
    if best_json.exists() or best_pt.exists():
        stale_or_unverifiable = not (best_json.exists() and best_pt.exists())
        if not stale_or_unverifiable:
            try:
                best_metadata = json.loads(best_json.read_text(encoding="utf-8"))
                best_payload = load_checkpoint(best_pt)
                json_step = int(best_metadata["step"])
                payload_step = int(best_payload["global_step"])
                stale_or_unverifiable = (
                    json_step != payload_step or json_step > boundary
                )
                del best_payload
            except Exception:
                stale_or_unverifiable = True
        if stale_or_unverifiable:
            for path in (best_json, best_pt):
                if path.exists():
                    quarantined.append(
                        str(_quarantine_path(path, quarantine_dir))
                    )

    prefix = "checkpoint_step_"
    suffix = ".pt"
    for path in sorted(run_dir.glob(f"{prefix}*{suffix}")):
        text = path.name[len(prefix) : -len(suffix)]
        try:
            step = int(text)
        except ValueError as exc:
            raise RuntimeError(
                f"unrecognized step checkpoint filename: {path.name}"
            ) from exc
        if step > boundary:
            quarantined.append(str(_quarantine_path(path, quarantine_dir)))
    return quarantined


def rollback_resume_outputs(
    run_dir: Path,
    payload: Dict[str, Any],
    metrics_fields: list[str],
    *,
    strict_assignment: bool,
    assignment_window_size: int,
) -> Dict[str, Any]:
    """Atomically restore append-only outputs to the checkpointed prefix."""
    report: Dict[str, Any] = dict(
        _rollback_metrics_outputs(run_dir, payload, metrics_fields)
    )
    if strict_assignment:
        report.update(
            _rollback_assignment_diagnostics(
                run_dir,
                payload,
                assignment_window_size,
            )
        )
    report["quarantined_checkpoint_evidence"] = (
        _quarantine_stale_checkpoint_evidence(run_dir, payload)
    )
    return report


def make_env(config: LiteConfig, seed: int, render: bool) -> Any:
    if config.task_name in {"fetch_push", "fetch_pick_and_place", "fetch_slide"}:
        return FetchGoalEnv(config.env_id, config.max_episode_steps, seed, render)
    if config.task_name == "unitree_apple":
        return UnitreeAppleGoalEnv(
            env_id=config.env_id,
            max_episode_steps=config.max_episode_steps,
            seed=seed,
            render=render,
            obs_mode=config.obs_mode,
            reward_type=config.reward_type,
            control_mode=config.control_mode,
            num_envs=config.num_envs,
            backend=config.backend,
            sim_backend=config.sim_backend,
        )
    if config.task_name == "pick_cube":
        return ManiSkillPickCubeGoalEnv(
            env_id=config.env_id,
            max_episode_steps=config.max_episode_steps,
            seed=seed,
            render=render,
            obs_mode=config.obs_mode,
            reward_type=config.reward_type,
            robot_uids=config.robot_uids,
            control_mode=config.control_mode,
            num_envs=config.num_envs,
            backend=config.backend,
            sim_backend=config.sim_backend,
        )
    if config.task_name == "push_t":
        return ManiSkillPushTGoalEnv(
            env_id=config.env_id,
            max_episode_steps=config.max_episode_steps,
            seed=seed,
            render=render,
            obs_mode=config.obs_mode,
            reward_type=config.reward_type,
            robot_uids=config.robot_uids,
            control_mode=config.control_mode,
            num_envs=config.num_envs,
            backend=config.backend,
            sim_backend=config.sim_backend,
            pos_success_thresh=config.push_t_pos_success_thresh,
            rot_success_thresh=config.push_t_rot_success_thresh,
            rot_weight=config.push_t_rot_weight,
            contact_thresh=config.push_t_contact_thresh,
        )
    raise ValueError(f"Unsupported task_name={config.task_name!r}")


def make_task_spec(config: LiteConfig, env: Any) -> Any:
    if config.task_name == "fetch_push":
        return FetchPushTaskSpec(
            action_low=env.action_low,
            action_high=env.action_high,
            epsilon_g=env.distance_threshold,
            d_contact=config.d_contact,
            d_goal_near=config.d_goal_near,
            ee_obj_bins=config.ee_obj_bins,
            obj_goal_bins=config.obj_goal_bins,
            horizon_bins=config.horizon_bins,
        )
    if config.task_name == "fetch_pick_and_place":
        return FetchPickAndPlaceTaskSpec(
            action_low=env.action_low,
            action_high=env.action_high,
            epsilon_g=env.distance_threshold,
            d_reach=config.d_reach,
            d_goal_near=config.d_goal_near,
            z_lift_min=config.z_lift_min,
            grip_close_thresh=config.grip_close_thresh,
            hand_obj_bins=config.pick_hand_obj_bins,
            obj_goal_bins=config.pick_obj_goal_bins,
            object_z_bins=config.pick_object_z_bins,
            gripper_gap_bins=config.pick_gripper_gap_bins,
            horizon_bins=config.horizon_bins,
        )
    if config.task_name == "fetch_slide":
        return FetchSlideTaskSpec(
            action_low=env.action_low,
            action_high=env.action_high,
            epsilon_g=env.distance_threshold,
            d_contact=config.slide_d_contact,
            d_goal_near=config.slide_d_goal_near,
            v_slide_min=config.slide_v_slide_min,
            v_fast=config.slide_v_fast,
            ee_obj_bins=config.slide_ee_obj_bins,
            obj_goal_bins=config.slide_obj_goal_bins,
            obj_speed_bins=config.slide_obj_speed_bins,
            vel_align_bins=config.slide_vel_align_bins,
            horizon_bins=config.horizon_bins,
        )
    if config.task_name == "unitree_apple":
        return UnitreeAppleTaskSpec(
            action_low=env.action_low,
            action_high=env.action_high,
            epsilon_g=env.distance_threshold,
            d_reach=config.d_reach,
            d_goal_near=config.d_goal_near,
            hand_apple_bins=config.hand_apple_bins,
            apple_goal_bins=config.apple_goal_bins,
            apple_z_bins=config.apple_z_bins,
            horizon_bins=config.horizon_bins,
        )
    if config.task_name == "pick_cube":
        z_lift_min = (
            float(config.pick_cube_z_lift_min)
            if config.pick_cube_z_lift_min is not None
            else float(getattr(env, "z_lift_min", 0.07))
        )
        return PickCubeTaskSpec(
            action_low=env.action_low,
            action_high=env.action_high,
            epsilon_g=env.distance_threshold,
            d_reach=config.d_reach,
            d_goal_near=env.distance_threshold,
            z_lift_min=z_lift_min,
            tcp_cube_bins=config.pick_cube_tcp_cube_bins,
            cube_goal_bins=config.pick_cube_goal_bins,
            cube_z_bins=config.pick_cube_z_bins,
            horizon_bins=config.horizon_bins,
            z_lift_min_source=str(getattr(env, "z_lift_min_source", "config")),
        )
    if config.task_name == "push_t":
        return PushTTaskSpec(
            action_low=env.action_low,
            action_high=env.action_high,
            pos_success_thresh=config.push_t_pos_success_thresh,
            rot_success_thresh=config.push_t_rot_success_thresh,
            contact_thresh=config.push_t_contact_thresh,
            pos_near_thresh=config.push_t_pos_near_thresh,
            rot_near_thresh=config.push_t_rot_near_thresh,
            rot_large_thresh=config.push_t_rot_large_thresh,
            speed_thresh=config.push_t_speed_thresh,
            ang_vel_thresh=config.push_t_ang_vel_thresh,
            tcp_obj_bins=config.push_t_tcp_obj_bins,
            obj_goal_dist_bins=config.push_t_obj_goal_dist_bins,
            rot_err_bins_rad=config.push_t_rot_err_bins_rad,
            obj_speed_bins=config.push_t_obj_speed_bins,
            ang_vel_bins=config.push_t_ang_vel_bins,
            horizon_bins=config.horizon_bins,
        )
    raise ValueError(f"Unsupported task_name={config.task_name!r}")


@torch.no_grad()
def evaluate_agent(
    agent: DDPGAgent,
    env: Any,
    eval_seed: int,
    eval_episodes: int,
    task: Any | None = None,
) -> Dict[str, float]:
    returns = []
    goal_successes_ever = []
    env_successes_ever = []
    goal_successes_final = []
    env_successes_final = []
    episode_lengths = []
    push_t_series: Dict[str, list[float]] = {}
    pos_progress = []
    rot_progress = []
    eval_obs = []
    eval_goals = []
    dummy_rng = np.random.default_rng(0)
    old_intersection_flag = getattr(env, "compute_intersection_ratio", None)
    if hasattr(env, "set_compute_intersection_ratio"):
        env.set_compute_intersection_ratio(True)
    try:
        for ep in range(eval_episodes):
            obs = env.reset(seed=eval_seed + ep)
            ep_ret = 0.0
            ep_goal_succ_ever = 0.0
            ep_env_succ_ever = 0.0
            ep_goal_succ_final = 0.0
            ep_env_succ_final = 0.0
            ep_len = 0
            prev_pos_dist = None
            prev_rot_err = None
            for _ in range(env.max_episode_steps):
                action = agent.act(obs.flat_state(), noise_std=0.0, noise_rng=dummy_rng)
                obs, reward, terminated, truncated, info = env.step(action)
                eval_obs.append(obs.observation.copy())
                eval_goals.append(obs.desired_goal.copy())
                ep_ret += float(reward)
                ep_len += 1
                goal_succ = float(info.get("goal_success", info.get("is_success", 0.0)))
                env_succ = float(info.get("env_success", info.get("is_success", goal_succ)))
                ep_goal_succ_ever = max(ep_goal_succ_ever, goal_succ)
                ep_env_succ_ever = max(ep_env_succ_ever, env_succ)
                ep_goal_succ_final = goal_succ
                ep_env_succ_final = env_succ
                for key, value in info.items():
                    if not str(key).startswith("pushT/"):
                        continue
                    try:
                        scalar = float(np.asarray(value).reshape(-1)[0])
                    except (TypeError, ValueError, IndexError):
                        continue
                    push_t_series.setdefault(str(key), []).append(scalar)
                pos_dist = info.get("pushT/obj_goal_xy_dist")
                rot_err = info.get("pushT/obj_goal_rot_err")
                if pos_dist is not None:
                    pos_value = float(np.asarray(pos_dist).reshape(-1)[0])
                    if prev_pos_dist is not None and np.isfinite(pos_value) and np.isfinite(prev_pos_dist):
                        pos_progress.append(float(pos_value < prev_pos_dist))
                    prev_pos_dist = pos_value
                if rot_err is not None:
                    rot_value = float(np.asarray(rot_err).reshape(-1)[0])
                    if prev_rot_err is not None and np.isfinite(rot_value) and np.isfinite(prev_rot_err):
                        rot_progress.append(float(rot_value < prev_rot_err))
                    prev_rot_err = rot_value
                if terminated or truncated:
                    break
            returns.append(ep_ret)
            goal_successes_ever.append(ep_goal_succ_ever)
            env_successes_ever.append(ep_env_succ_ever)
            goal_successes_final.append(ep_goal_succ_final)
            env_successes_final.append(ep_env_succ_final)
            episode_lengths.append(ep_len)
    finally:
        if old_intersection_flag is not None and hasattr(env, "set_compute_intersection_ratio"):
            env.set_compute_intersection_ratio(bool(old_intersection_flag))

    env_ever_mean = float(np.mean(env_successes_ever) if env_successes_ever else 0.0)
    goal_ever_mean = float(np.mean(goal_successes_ever) if goal_successes_ever else 0.0)
    env_final_mean = float(np.mean(env_successes_final) if env_successes_final else 0.0)
    goal_final_mean = float(np.mean(goal_successes_final) if goal_successes_final else 0.0)
    metrics = {
        "eval_return_mean": float(np.mean(returns) if returns else 0.0),
        "eval_return_std": float(np.std(returns) if returns else 0.0),
        "eval_success_mean": env_ever_mean,
        "eval_success_std": float(np.std(env_successes_ever) if env_successes_ever else 0.0),
        "eval_goal_success_mean": goal_ever_mean,
        "eval_goal_success_std": float(np.std(goal_successes_ever) if goal_successes_ever else 0.0),
        "eval_env_success_mean": env_ever_mean,
        "eval_env_success_std": float(np.std(env_successes_ever) if env_successes_ever else 0.0),
        "eval_goal_success_ever_mean": goal_ever_mean,
        "eval_goal_success_ever_std": float(np.std(goal_successes_ever) if goal_successes_ever else 0.0),
        "eval_env_success_ever_mean": env_ever_mean,
        "eval_env_success_ever_std": float(np.std(env_successes_ever) if env_successes_ever else 0.0),
        "eval_goal_success_final_mean": goal_final_mean,
        "eval_goal_success_final_std": float(np.std(goal_successes_final) if goal_successes_final else 0.0),
        "eval_env_success_final_mean": env_final_mean,
        "eval_env_success_final_std": float(np.std(env_successes_final) if env_successes_final else 0.0),
        "eval_episode_length_mean": float(np.mean(episode_lengths) if episode_lengths else 0.0),
    }
    push_specs = {
        "pushT/obj_goal_xy_dist": ("pushT/obj_goal_xy_dist_mean", "pushT/obj_goal_xy_dist_p50", "pushT/obj_goal_xy_dist_p90"),
        "pushT/obj_goal_rot_err": ("pushT/obj_goal_rot_err_mean", "pushT/obj_goal_rot_err_p50", "pushT/obj_goal_rot_err_p90"),
        "pushT/intersection_ratio": (
            "pushT/intersection_ratio_mean",
            "pushT/intersection_ratio_p50",
            "pushT/intersection_ratio_p90",
        ),
    }
    for raw_key, out_keys in push_specs.items():
        arr = np.asarray(push_t_series.get(raw_key, []), dtype=np.float32)
        metrics[out_keys[0]] = _nanmean(arr)
        metrics[out_keys[1]] = _nanpercentile(arr, 50.0)
        metrics[out_keys[2]] = _nanpercentile(arr, 90.0)
    for raw_key, out_key in {
        "pushT/success_margin": "pushT/success_margin_mean",
        "pushT/tcp_obj_dist": "pushT/tcp_obj_dist_mean",
        "pushT/contact_like": "pushT/contact_like_rate",
        "pushT/obj_speed_xy": "pushT/obj_speed_xy_mean",
        "pushT/obj_ang_vel_z_abs": "pushT/obj_ang_vel_z_abs_mean",
        "pushT/vel_align_to_goal": "pushT/vel_align_to_goal_mean",
    }.items():
        metrics[out_key] = _nanmean(np.asarray(push_t_series.get(raw_key, []), dtype=np.float32))
    metrics["pushT/pos_progress_rate"] = _nanmean(np.asarray(pos_progress, dtype=np.float32))
    metrics["pushT/rot_progress_rate"] = _nanmean(np.asarray(rot_progress, dtype=np.float32))
    if task is not None and hasattr(task, "diagnostic_metrics") and eval_obs:
        task_metrics = task.diagnostic_metrics(
            np.asarray(eval_obs, dtype=np.float32),
            np.asarray(eval_goals, dtype=np.float32),
        )
        for key, value in task_metrics.items():
            if str(key).startswith("pushT/phase_"):
                metrics[key] = float(value)
            elif key not in metrics or not np.isfinite(float(metrics[key])):
                metrics[key] = float(value)
    return metrics


def _mean(arr: np.ndarray) -> float:
    return float(np.mean(arr)) if arr.size else 0.0


def _nanmean(arr: np.ndarray) -> float:
    values = np.asarray(arr, dtype=np.float32)
    if values.size == 0 or np.all(np.isnan(values)):
        return float("nan")
    return float(np.nanmean(values))


def _nanpercentile(arr: np.ndarray, percentile: float) -> float:
    values = np.asarray(arr, dtype=np.float32)
    if values.size == 0 or np.all(np.isnan(values)):
        return float("nan")
    return float(np.nanpercentile(values, percentile))


def _auc_success(history: list[tuple[int, float]]) -> float:
    if not history:
        return float("nan")
    if len(history) == 1:
        return float(history[0][1])
    steps = np.asarray([step for step, _ in history], dtype=np.float64)
    values = np.asarray([value for _, value in history], dtype=np.float64)
    span = max(1.0, float(steps[-1] - steps[0]))
    trapezoid = getattr(np, "trapezoid", None)
    if trapezoid is None:
        trapezoid = np.trapz
    return float(trapezoid(values, steps) / span)


def _first_hit(history: list[tuple[int, float]], threshold: float) -> str:
    for step, value in history:
        if value >= threshold:
            return str(int(step))
    return ""


def _entropy_weight(w: np.ndarray, eps: float) -> float:
    if w.size == 0:
        return 0.0
    p = np.maximum(w.astype(np.float64), eps)
    p = p / max(eps, float(p.sum()))
    return float(-(p * np.log(p + eps)).sum())


def _ess_weight(w: np.ndarray, eps: float) -> float:
    values = np.maximum(np.asarray(w, dtype=np.float64), eps)
    if values.size == 0:
        return 0.0
    return float((values.sum() ** 2) / max(eps, float(np.sum(values ** 2))))


def _apply_td_or_per_loss_weights(
    config: LiteConfig,
    agent: DDPGAgent,
    wb: Any,
    state: torch.Tensor,
    action_exec: torch.Tensor,
    reward: torch.Tensor,
    next_state: torch.Tensor,
    nonterminal: torch.Tensor,
) -> None:
    td_abs = agent.td_error_abs(state, action_exec, reward, next_state, nonterminal).detach().cpu().numpy().astype(np.float32)
    eps = float(config.eps)
    if config.method == "td_error":
        td_norm = td_abs / max(eps, float(np.mean(td_abs)))
        clipped = np.clip(td_norm, 0.0, float(config.U_TD_max)).astype(np.float32)
        w_raw = (1.0 + float(config.lambda_TD) * clipped).astype(np.float32)
        wb.extra_metrics.update(
            {
                "td_error/abs_mean": float(np.mean(td_abs)) if td_abs.size else 0.0,
                "td_error/abs_p90": _nanpercentile(td_abs, 90.0),
                "td_error/weight_mean": float(np.mean(w_raw)) if w_raw.size else 1.0,
                "td_error/weight_max": float(np.max(w_raw)) if w_raw.size else 1.0,
                "td_error/weight_entropy": _entropy_weight(w_raw, eps),
                "td_error/weight_ESS": _ess_weight(w_raw, eps),
            }
        )
    elif config.method == "per_style_loss_weighting":
        priority = np.power(td_abs + float(config.eps_PER), float(config.per_alpha)).astype(np.float32)
        p_norm = priority / max(eps, float(np.mean(priority)))
        w_raw = np.clip(p_norm, 0.0, float(config.U_PER_max)).astype(np.float32)
        wb.extra_metrics.update(
            {
                "per/priority_entropy": _entropy_weight(priority, eps),
                "per/priority_ESS": _ess_weight(priority, eps),
                "per/weight_mean": float(np.mean(w_raw)) if w_raw.size else 1.0,
                "per/weight_max": float(np.max(w_raw)) if w_raw.size else 1.0,
                "per/weight_entropy": _entropy_weight(w_raw, eps),
                "per/weight_ESS": _ess_weight(w_raw, eps),
            }
        )
    else:
        return
    omega = (w_raw / max(eps, float(np.mean(w_raw)))).astype(np.float32)
    wb.w_p_raw = w_raw.astype(np.float32)
    wb.omega_critic = omega
    wb.omega_actor = np.ones_like(omega, dtype=np.float32)


def _task_phase_names(task: Any) -> tuple[str, ...]:
    names = getattr(task, "phase_names", None)
    if callable(names):
        names = names()
    if names is None:
        metadata = task.metadata() if hasattr(task, "metadata") else {}
        labels = metadata.get("phase_labels", {}) if isinstance(metadata, dict) else {}
        if labels:
            names = [name for _, name in sorted(labels.items(), key=lambda item: int(item[0]))]
    if names is None:
        names = ("approach", "grasp", "transport", "release_place")
    return tuple(str(name) for name in names)


def run_training(config: LiteConfig, repo_root: Path) -> Path:
    config.normalize()
    output_root = config.output_root_path(repo_root)
    run_dir = make_run_dir(output_root, config.run_name, config.resume)
    run_dir.mkdir(parents=True, exist_ok=True)
    logger = setup_logger(run_dir / "run.log")

    set_all_seeds(config.seeds.torch_seed, config.seeds.numpy_seed)
    device = select_device(config.device)
    logger.info("device=%s", device)

    train_env = make_env(config, config.seeds.env_seed, config.render)
    eval_env = make_env(config, config.seeds.eval_seed, False)
    if config.policy_support_mode == "auto":
        config.policy_support_mode = "bin" if int(train_env.action_dim) <= 4 else "radius"
        logger.info(
            "resolved policy_support_mode=%s for action_dim=%d",
            config.policy_support_mode,
            train_env.action_dim,
        )
    task = make_task_spec(config, train_env)
    phase_names = _task_phase_names(task)
    agent = DDPGAgent(
        state_dim=train_env.state_dim,
        action_dim=train_env.action_dim,
        hidden_dim=config.hidden_dim,
        actor_lr=config.actor_lr,
        critic_lr=config.critic_lr,
        gamma=config.gamma,
        tau=config.tau,
        action_low=train_env.action_low,
        action_high=train_env.action_high,
        device=device,
        l2_action_penalty=config.l2_action_penalty,
    )
    replay = HERReplayBuffer(
        capacity=config.buffer_capacity,
        obs_dim=train_env.obs_dim,
        goal_dim=train_env.goal_dim,
        action_dim=train_env.action_dim,
    )
    gap_stats = GapStats(
        maxlen=config.gap_window,
        n_min=config.N_gap_min,
        q_low=config.gap_q_low,
        q_high=config.gap_q_high,
        eps_g=config.eps_G,
    )
    weight_computer = LiteWeightComputer(config, task, gap_stats)

    write_json(
        run_dir / "config.json",
        {
            **config.as_dict(),
            "thread_hint": env_thread_hint(),
            "terminal_convention": {
                "success_terminates": config.success_terminates,
                "timeout_bootstrap": config.timeout_bootstrap,
            },
        },
    )
    train_env_snapshot = train_env.snapshot()
    eval_env_snapshot = eval_env.snapshot()
    task_metadata = task.metadata()
    write_json(
        run_dir / "env_snapshot.json",
        {
            "train_env": train_env_snapshot,
            "eval_env": eval_env_snapshot,
            "task_spec": task_metadata,
        },
    )
    if config.task_name == "push_t":
        logger.info(
            "PushT assumptions: official_success=eval_env_success pose_goal_success=eval_goal_success "
            "goal_theta_source=%s velocity_available=%s intersection_train=%s intersection_eval=%s "
            "phase_names=%s max_episode_steps=%d action_dim=%d obs_dim=%d goal_dim=%d",
            train_env_snapshot.get("goal_theta_source"),
            train_env_snapshot.get("velocity_available"),
            train_env_snapshot.get("compute_intersection_ratio_default"),
            train_env_snapshot.get("compute_intersection_ratio_eval_enabled_by_trainer"),
            list(phase_names),
            train_env.max_episode_steps,
            train_env.action_dim,
            train_env.obs_dim,
            train_env.goal_dim,
        )

    fields = [
        "step",
        "episode",
        "train/episode_return",
        "train/episode_success",
        "train/episode_len",
        "train/replay_size",
        "train/her_relabel_ratio",
        "config/lambda_support",
        "config/weight_scope",
        "config/support_query_mode",
        "config/support_assignment_mode",
        "loss/critic",
        "loss/actor",
        "loss/td_error_abs_mean",
        "loss/td_error_abs_p90",
        "value/q_mean",
        "value/target_mean",
        "critic/q_policy_mean",
        "critic/q_policy_std",
        "critic/q_target_mean",
        "critic/q_target_std",
        "critic/q_abs_mean",
        "critic/q_abs_max",
        "lite/mean_G_sup",
        "lite/positive_G_sup_rate",
        "lite/mean_kappa",
        "lite/mean_w_P",
        "lite/max_w_P",
        "lite/std_w_P",
        "lite/entropy_w_P",
        "lite/ESS_w",
        "lite/ESS_w_normalized",
        "lite/support_available_rate",
        "lite/psi_q_rank_rate",
        "lite/q_candidate_fallback_rate",
        "lite/psi_A_policy_rate",
        "lite/psi_A_query_rate",
        "query/context_count_eligible_rate",
        "query/support_positive_rate",
        "query/query_bin_present_given_context_rate",
        "query/high_weight_count",
        "query/raw_weight_mean",
        "query/raw_weight_std",
        "query/raw_weight_ESS",
        "query/normalized_weight_mean",
        "query/normalized_weight_std",
        "query/normalized_weight_ESS",
        "query/query_bin_matches_current_policy_rate",
        "query/query_bin_matches_replay_action_rate",
        "lite/mean_len_A_Q_sup",
        "lite/mean_len_A_Q_replay_local",
        "lite/local_support_count_mean",
        "lite/local_support_count_p50",
        "lite/local_support_count_p90",
        "lite/mean_num_coarse_candidates",
        "lite/mean_num_scanned_candidates",
        "lite/local_scan_truncated_rate",
        "lite/mean_Q_imp_minus_Q_policy",
        "lite/unrestricted_gap_mean",
        "lite/gap_ready",
        "lite/gap_tau",
        "lite/gap_max",
        "time/local_context_lookup",
        "time/candidate_construction",
        "time/local_context",
        "time/q_policy_eval",
        "time/q_candidate_eval",
        "time/weight_compute",
        "time/actor_critic_update",
        "time/numba_support_scan",
        "time_local_context_lookup",
        "time_candidate_construction",
        "time_q_policy_eval",
        "time_q_candidate_eval",
        "time_weight_computation",
        "time_actor_critic_update",
        "runtime/steps_per_sec",
        "runtime/total_sec",
        "runtime/overhead_vs_B0",
        "runtime/support_cache_hit_rate",
        "runtime/support_cache_miss_rate",
        "runtime/batch_query_unique_rate",
        "runtime/batch_query_coalescing_saving_rate",
        "runtime/coarse_query_unique_rate",
        "runtime/local_scan_cache_hit_rate",
        "runtime/local_scan_cache_miss_rate",
        "runtime/full_context_scan_rate",
        "runtime/exact_negative_short_circuit_rate",
        "runtime/count_short_circuit_rate",
        "runtime/threshold_short_circuit_rate",
        "runtime/coarse_count_short_circuit_rate",
        "runtime/coarse_support_size_short_circuit_rate",
        "runtime/scanned_count_short_circuit_rate",
        "runtime/coarse_action_bin_count_lookup_rate",
        "runtime/support_cache_attempt_rate",
        "runtime/support_context_cache_size",
        "runtime/local_scan_cache_attempt_rate",
        "runtime/local_scan_cache_size",
        "runtime/full_context_filter_count_mean",
        "runtime/numba_support_scan_enabled",
        "runtime/numba_scanner_warmed",
        "runtime/numba_support_scan_fallback_rate",
        "runtime/numba_support_queries",
        "runtime/predicate_early_exit_rate",
        "runtime/predicate_scanned_count_mean",
        "runtime/diagnostic_audit_rate",
        "runtime/audit_len_A_Q_local_abs_diff_mean",
        "runtime/audit_len_A_Q_sup_abs_diff_mean",
        "runtime/audit_psi_A_policy_mismatch_rate",
        "runtime/audit_psi_A_query_mismatch_rate",
        "runtime/context_count_eligible_rate",
        "mean_w_P_reference",
        "reference_high_weight_rate",
        "assigned_high_weight_rate",
        "support_weight_alignment_rate",
        "support_cache_hit_rate",
        "short_circuit_rate",
        "lite/mean_w_P_reference",
        "lite/reference_high_weight_rate",
        "lite/assigned_high_weight_rate",
        "lite/support_weight_alignment_rate",
        "lite/support_cache_hit_rate",
        "lite/short_circuit_rate",
        "lite/runtime_opt_exact_path",
        "td_error/abs_mean",
        "td_error/abs_p90",
        "td_error/weight_mean",
        "td_error/weight_max",
        "td_error/weight_entropy",
        "td_error/weight_ESS",
        "per/priority_entropy",
        "per/priority_ESS",
        "per/weight_mean",
        "per/weight_max",
        "per/weight_entropy",
        "per/weight_ESS",
        "lite/slide_mean_obj_speed",
        "lite/slide_mean_vel_align",
        "lite/slide_phase_distribution_approach",
        "lite/slide_phase_distribution_strike",
        "lite/slide_phase_distribution_slide",
        "lite/slide_phase_distribution_near_goal",
        "eval/return_mean",
        "eval/success_mean",
        "eval/goal_success_mean",
        "eval/env_success_mean",
        "eval/goal_success_ever_mean",
        "eval/goal_success_ever_std",
        "eval/env_success_ever_mean",
        "eval/env_success_ever_std",
        "eval/goal_success_final_mean",
        "eval/goal_success_final_std",
        "eval/env_success_final_mean",
        "eval/env_success_final_std",
        "eval/episode_length_mean",
        "eval/final_success",
        "eval/best_success",
        "eval/AUC_success",
        "eval/first_hit_0.25",
        "eval/first_hit_0.50",
        "eval/first_hit_0.75",
        "eval/first_hit_0.90",
        "pushT/obj_goal_xy_dist_mean",
        "pushT/obj_goal_xy_dist_p50",
        "pushT/obj_goal_xy_dist_p90",
        "pushT/obj_goal_rot_err_mean",
        "pushT/obj_goal_rot_err_p50",
        "pushT/obj_goal_rot_err_p90",
        "pushT/intersection_ratio_mean",
        "pushT/intersection_ratio_p50",
        "pushT/intersection_ratio_p90",
        "pushT/success_margin_mean",
        "pushT/tcp_obj_dist_mean",
        "pushT/contact_like_rate",
        "pushT/obj_speed_xy_mean",
        "pushT/obj_ang_vel_z_abs_mean",
        "pushT/vel_align_to_goal_mean",
        "pushT/pos_progress_rate",
        "pushT/rot_progress_rate",
        "b2/unrestricted_gap_mean",
        "b2/unrestricted_gap_p95",
        "b2/candidate_action_norm_mean",
        "b2/action_delta_norm_mean",
        "b2/q_imp_minus_q_policy_mean",
        "b2/high_gap_rate",
        "b2/gap_to_pos_progress_corr",
        "b2/gap_to_rot_progress_corr",
        "b2/high_gap_bad_progress_rate",
        "b3/support_available_rate",
        "b3/local_support_count_mean",
        "b3/local_support_count_p50",
        "b3/local_support_count_p90",
        "b3/support_to_pos_progress_corr",
        "b3/support_to_rot_progress_corr",
        "b3/support_to_success_corr",
        "b3/support_to_td_error_corr",
        "b4/G_sup_mean",
        "b4/G_sup_positive_rate",
        "b4/support_candidate_count_mean",
        "b4/support_candidate_count_p50",
        "b4/support_candidate_count_p90",
        "b4/fallback_rate",
        "b4/local_scan_truncated_rate",
        "b4/B2_gap_minus_B4_gap",
        "b4/unsupported_gap_rate",
    ]
    fields.extend(
        [
            "assignment/enabled",
            *TRACKED_METRICS.values(),
            *COUNT_METRICS.values(),
        ]
    )
    for phase_name in phase_names:
        fields.extend(
            [
                f"lite/phase_{phase_name}_mean_w_P",
                f"lite/phase_{phase_name}_fallback_rate",
                f"lite/phase_{phase_name}_psi_q_rank_rate",
                f"lite/phase_{phase_name}_positive_G_sup_rate",
                f"lite/phase_{phase_name}_count_rate",
                f"query/support_positive_rate_phase_{phase_name}",
                f"pushT/phase_{phase_name}_obj_goal_xy_dist_mean",
                f"pushT/phase_{phase_name}_obj_goal_rot_err_mean",
                f"pushT/phase_{phase_name}_contact_like_rate",
                f"pushT/phase_{phase_name}_intersection_ratio_mean",
                f"b3/support_by_phase_{phase_name}",
                f"b3/mean_w_P_by_phase_{phase_name}",
                f"b3/fallback_by_phase_{phase_name}",
            ]
        )
    fields = list(dict.fromkeys(fields))
    assignment_diagnostics = AssignmentDiagnosticsWindow(
        config.assignment_diagnostic_window_updates
    )

    noise_rng = np.random.default_rng(config.seeds.action_noise_seed)
    sample_rng = np.random.default_rng(config.seeds.numpy_seed + 17)
    weight_rng = np.random.default_rng(config.seeds.weight_seed)
    assignment_rng = np.random.default_rng(config.seeds.assignment_seed)
    start_step = 0
    episode_idx = 0
    total_updates = 0
    selection_metric = "eval_env_success_mean" if config.task_name == "push_t" else "eval_goal_success_mean"
    best_eval_success = -1.0
    best_eval_selection_success = -1.0
    best_eval_goal_success = -1.0
    best_eval_env_success = -1.0
    best_eval_return = float("-inf")
    best_eval_step = -1
    last_eval_metrics: Dict[str, float] = {}
    eval_history_env: list[tuple[int, float]] = []
    last_loss = {
        "critic": 0.0,
        "actor": 0.0,
        "q_mean": 0.0,
        "target_mean": 0.0,
        "q_std": 0.0,
        "target_std": 0.0,
        "q_abs_mean": 0.0,
        "q_abs_max": 0.0,
        "td_error_abs_mean": 0.0,
        "td_error_abs_p90": 0.0,
    }
    last_lite = _empty_lite_metrics(phase_names)
    last_her_ratio = 0.0

    ckpt_path = Path(config.resume_path) if config.resume_path else _checkpoint_path(run_dir)
    if config.resume:
        if not ckpt_path.is_file():
            raise FileNotFoundError(
                f"resume requested but checkpoint does not exist: {ckpt_path}"
            )
        payload = load_checkpoint(ckpt_path)
        validate_resume_checkpoint_config(config, payload)
        agent.load_state_dict(payload["agent"])
        replay.load_state_dict(payload["replay"])
        if replay.indexed_slot_count() < replay.size:
            replay.rebuild_action_index(task.coarse_hash_batch(replay.observation[:replay.size], replay.h[:replay.size]))
            logger.info("rebuilt replay action index slots=%d", replay.indexed_slot_count())
        replay.rebuild_action_bins(task.action_bin_batch(replay.action_exec[:replay.size], config.action_bins_per_dim))
        gap_stats.load_state_dict(payload.get("gap_stats", {}))
        (
            start_step,
            episode_idx,
            total_updates,
            last_her_ratio,
            last_eval_metrics,
            eval_history_env,
        ) = restore_training_progress(payload, last_loss, last_lite)
        best_eval_success = float(payload.get("best_eval_success", -1.0))
        best_eval_selection_success = float(payload.get("best_eval_selection_success", best_eval_success))
        best_eval_goal_success = float(payload.get("best_eval_goal_success", -1.0))
        best_eval_env_success = float(payload.get("best_eval_env_success", -1.0))
        best_eval_return = float(payload.get("best_eval_return", float("-inf")))
        best_eval_step = int(payload.get("best_eval_step", -1))
        noise_rng.bit_generator.state = payload["noise_rng_state"]
        sample_rng.bit_generator.state = payload["sample_rng_state"]
        weight_rng.bit_generator.state = payload["weight_rng_state"]
        restore_assignment_checkpoint_state(
            config,
            payload,
            assignment_rng,
            assignment_diagnostics,
        )
        rollback_report = rollback_resume_outputs(
            run_dir,
            payload,
            fields,
            strict_assignment=(
                config.support_assignment_mode in COUNT_MATCHED_ASSIGNMENT_MODES
            ),
            assignment_window_size=(
                config.assignment_diagnostic_window_updates
            ),
        )
        rollback_report.update(
            canonicalize_resume_checkpoint(run_dir, ckpt_path, payload)
        )
        logger.info("resume output rollback=%s", rollback_report)
        logger.info("resumed from %s at step=%d", ckpt_path, start_step)

    # Append-only writers must not be opened until checkpoint restoration and
    # fail-closed rollback have established a single, validated output prefix.
    csv_writer = MetricsCSVWriter(run_dir / "metrics.csv", fields)
    jsonl_writer = MetricsJSONLWriter(run_dir / "metrics.jsonl")
    assignment_diagnostics_writer = MetricsCSVWriter(
        run_dir / "assignment_diagnostics_1000.csv",
        ASSIGNMENT_DIAGNOSTIC_FIELDS,
    )

    obs = train_env.reset(seed=config.seeds.env_seed + episode_idx)
    ep_return = 0.0
    ep_success = 0.0
    ep_step = 0
    global_step = start_step
    wall_start = time.perf_counter()

    def checkpoint_payload(step_value: int, kind: str) -> Dict[str, Any]:
        return {
            "checkpoint_kind": kind,
            "config": config.as_dict(),
            "global_step": int(step_value),
            "episode_idx": episode_idx,
            "total_updates": total_updates,
            "selection_metric": selection_metric,
            "best_eval_success": best_eval_success,
            "best_eval_selection_success": best_eval_selection_success,
            "best_eval_goal_success": best_eval_goal_success,
            "best_eval_env_success": best_eval_env_success,
            "best_eval_return": best_eval_return,
            "best_eval_step": best_eval_step,
            "last_eval_metrics": dict(last_eval_metrics),
            "eval_history_env": list(eval_history_env),
            "last_loss": dict(last_loss),
            "last_lite": dict(last_lite),
            "last_her_ratio": float(last_her_ratio),
            "agent": agent.state_dict(),
            "replay": replay.state_dict(),
            "gap_stats": gap_stats.state_dict(),
            "noise_rng_state": noise_rng.bit_generator.state,
            "sample_rng_state": sample_rng.bit_generator.state,
            "weight_rng_state": weight_rng.bit_generator.state,
            "assignment_rng_state": assignment_rng.bit_generator.state,
            "assignment_diagnostics_state": assignment_diagnostics.state_dict(),
        }

    while global_step < config.total_steps:
        h_t = train_env.max_episode_steps - ep_step
        if global_step < config.start_steps:
            action = noise_rng.uniform(train_env.action_low, train_env.action_high).astype(np.float32)
        else:
            action = agent.act(obs.flat_state(), noise_std=config.noise_std, noise_rng=noise_rng)

        obs_next, reward_ext, terminated, truncated, info = train_env.step(action)
        done = bool(terminated or truncated)
        timeout = bool(truncated)
        ep_return += float(reward_ext)
        ep_success = max(ep_success, float(info.get("goal_success", info.get("is_success", 0.0))))

        replay.add_transition(
            observation=obs.observation,
            achieved_goal=obs.achieved_goal,
            desired_goal=obs.desired_goal,
            action_exec=action,
            reward_ext=reward_ext,
            next_observation=obs_next.observation,
            next_achieved_goal=obs_next.achieved_goal,
            done=done,
            timeout=timeout,
            h=h_t,
            episode_id=episode_idx,
            episode_step=ep_step,
            coarse_key=task.coarse_hash(obs.observation, h_t),
            action_bin=int(task.action_bin_batch(action[None, :], config.action_bins_per_dim)[0]),
        )

        obs = obs_next
        ep_step += 1
        global_step += 1

        if replay.size >= config.batch_size and global_step >= config.warmup_steps:
            for _ in range(config.updates_per_step):
                batch = replay.sample(config.batch_size, config.her_ratio, sample_rng)
                last_her_ratio = batch.her_relabel_ratio
                reward_train = train_env.compute_reward(batch.next_achieved_goal, batch.desired_goal_train, {})
                success_train = train_env.success_from_goal(batch.next_achieved_goal, batch.desired_goal_train)
                env_terminal = batch.done.astype(np.float32) * (1.0 - batch.timeout.astype(np.float32))
                if not config.timeout_bootstrap:
                    env_terminal = np.maximum(env_terminal, batch.timeout.astype(np.float32))
                terminal = env_terminal.copy()
                if config.success_terminates:
                    terminal = np.maximum(terminal, success_train.astype(np.float32))
                nonterminal = (1.0 - terminal).astype(np.float32)

                wb = weight_computer.compute(
                    batch,
                    replay,
                    agent,
                    weight_rng,
                    device,
                    assignment_rng=assignment_rng,
                )
                state_np = np.concatenate([batch.observation, batch.desired_goal_train], axis=1).astype(np.float32)
                next_state_np = np.concatenate([batch.next_observation, batch.desired_goal_train], axis=1).astype(np.float32)
                state_t = torch.as_tensor(state_np, dtype=torch.float32, device=device)
                action_t = torch.as_tensor(batch.action_exec, dtype=torch.float32, device=device)
                reward_t = torch.as_tensor(reward_train, dtype=torch.float32, device=device)
                next_state_t = torch.as_tensor(next_state_np, dtype=torch.float32, device=device)
                nonterminal_t = torch.as_tensor(nonterminal, dtype=torch.float32, device=device)
                if config.method in {"td_error", "per_style_loss_weighting"}:
                    _apply_td_or_per_loss_weights(
                        config=config,
                        agent=agent,
                        wb=wb,
                        state=state_t,
                        action_exec=action_t,
                        reward=reward_t,
                        next_state=next_state_t,
                        nonterminal=nonterminal_t,
                    )

                t_update0 = time.perf_counter()
                update = agent.update(
                    state=state_t,
                    action_exec=action_t,
                    reward=reward_t,
                    next_state=next_state_t,
                    nonterminal=nonterminal_t,
                    omega_critic=torch.as_tensor(wb.omega_critic, dtype=torch.float32, device=device),
                    omega_actor=torch.as_tensor(wb.omega_actor, dtype=torch.float32, device=device),
                )
                t_update1 = time.perf_counter()
                last_loss = {
                    "critic": update.critic_loss,
                    "actor": update.actor_loss,
                    "q_mean": update.q_mean,
                    "target_mean": update.target_mean,
                    "q_std": update.q_std,
                    "target_std": update.target_std,
                    "q_abs_mean": update.q_abs_mean,
                    "q_abs_max": update.q_abs_max,
                    "td_error_abs_mean": update.td_error_abs_mean,
                    "td_error_abs_p90": update.td_error_abs_p90,
                }
                last_lite = _lite_metrics_from_weight_batch(wb, phase_names)
                last_lite["time/actor_critic_update"] = float(t_update1 - t_update0)
                last_lite["time_actor_critic_update"] = float(t_update1 - t_update0)
                total_updates += 1
                if (
                    config.support_assignment_mode
                    in COUNT_MATCHED_ASSIGNMENT_MODES
                ):
                    assignment_diagnostic_row = assignment_diagnostics.update(
                        total_updates,
                        wb.extra_metrics,
                    )
                    if assignment_diagnostic_row is not None:
                        assignment_diagnostics_writer.write(
                            assignment_diagnostic_row
                        )

        if done:
            episode_idx += 1
            row = _metric_row(
                global_step,
                episode_idx,
                ep_return,
                ep_success,
                ep_step,
                replay.size,
                last_her_ratio,
                last_loss,
                last_lite,
                config,
            )
            _add_runtime(row, wall_start, global_step)
            csv_writer.write(row)
            jsonl_writer.write({"type": "episode", **row})
            obs = train_env.reset(seed=config.seeds.env_seed + episode_idx)
            ep_return = 0.0
            ep_success = 0.0
            ep_step = 0

        do_eval = (global_step % config.eval_freq == 0) or (global_step == config.total_steps)
        if do_eval and global_step > 0:
            eval_metrics = evaluate_agent(
                agent,
                eval_env,
                eval_seed=config.seeds.eval_seed + global_step * 10,
                eval_episodes=config.eval_episodes,
                task=task,
            )
            row = _metric_row(
                global_step,
                episode_idx,
                ep_return,
                ep_success,
                ep_step,
                replay.size,
                last_her_ratio,
                last_loss,
                last_lite,
                config,
            )
            _add_runtime(row, wall_start, global_step)
            row["eval/return_mean"] = eval_metrics["eval_return_mean"]
            row["eval/success_mean"] = eval_metrics["eval_success_mean"]
            row["eval/goal_success_mean"] = eval_metrics["eval_goal_success_mean"]
            row["eval/env_success_mean"] = eval_metrics["eval_env_success_mean"]
            row["eval/goal_success_ever_mean"] = eval_metrics["eval_goal_success_ever_mean"]
            row["eval/goal_success_ever_std"] = eval_metrics["eval_goal_success_ever_std"]
            row["eval/env_success_ever_mean"] = eval_metrics["eval_env_success_ever_mean"]
            row["eval/env_success_ever_std"] = eval_metrics["eval_env_success_ever_std"]
            row["eval/goal_success_final_mean"] = eval_metrics["eval_goal_success_final_mean"]
            row["eval/goal_success_final_std"] = eval_metrics["eval_goal_success_final_std"]
            row["eval/env_success_final_mean"] = eval_metrics["eval_env_success_final_mean"]
            row["eval/env_success_final_std"] = eval_metrics["eval_env_success_final_std"]
            row["eval/episode_length_mean"] = eval_metrics["eval_episode_length_mean"]
            last_eval_metrics = dict(eval_metrics)
            eval_history_env.append((global_step, float(eval_metrics["eval_env_success_mean"])))
            row["eval/final_success"] = eval_metrics["eval_env_success_final_mean"]
            row["eval/best_success"] = max(value for _, value in eval_history_env)
            row["eval/AUC_success"] = _auc_success(eval_history_env)
            for threshold in (0.25, 0.50, 0.75, 0.90):
                row[f"eval/first_hit_{threshold:.2f}"] = _first_hit(eval_history_env, threshold)
            for key, value in eval_metrics.items():
                if str(key).startswith("pushT/"):
                    row[key] = value
            csv_writer.write(row)
            jsonl_writer.write({"type": "eval", **row, **eval_metrics})
            selection_success = float(eval_metrics[selection_metric])
            is_best = (selection_success > best_eval_selection_success) or (
                np.isclose(selection_success, best_eval_selection_success)
                and eval_metrics["eval_return_mean"] > best_eval_return
            )
            if is_best:
                best_eval_selection_success = selection_success
                best_eval_success = selection_success
                best_eval_goal_success = float(eval_metrics["eval_goal_success_mean"])
                best_eval_env_success = float(eval_metrics["eval_env_success_mean"])
                best_eval_return = eval_metrics["eval_return_mean"]
                best_eval_step = global_step
                save_checkpoint(_best_checkpoint_path(run_dir), checkpoint_payload(global_step, "best_eval"))
                write_json(
                    run_dir / "best_checkpoint.json",
                    {
                        "checkpoint": str(_best_checkpoint_path(run_dir)),
                        "step": global_step,
                        "selection_metric": selection_metric,
                        "eval_success_mean": best_eval_success,
                        "eval_goal_success_mean": eval_metrics["eval_goal_success_mean"],
                        "eval_env_success_mean": eval_metrics["eval_env_success_mean"],
                        "eval_goal_success_ever_mean": eval_metrics["eval_goal_success_ever_mean"],
                        "eval_env_success_ever_mean": eval_metrics["eval_env_success_ever_mean"],
                        "eval_goal_success_final_mean": eval_metrics["eval_goal_success_final_mean"],
                        "eval_env_success_final_mean": eval_metrics["eval_env_success_final_mean"],
                        "eval_return_mean": best_eval_return,
                    },
                )
            logger.info(
                "step=%d episode=%d replay=%d eval_goal=%.3f eval_env=%.3f eval_ret=%.2f wP=%.3f psiQ=%.3f fallback=%.3f",
                global_step,
                episode_idx,
                replay.size,
                eval_metrics["eval_goal_success_mean"],
                eval_metrics["eval_env_success_mean"],
                eval_metrics["eval_return_mean"],
                last_lite["lite/mean_w_P"],
                last_lite["lite/psi_q_rank_rate"],
                last_lite["lite/q_candidate_fallback_rate"],
            )

        do_ckpt = (global_step % config.checkpoint_every_steps == 0 and global_step > 0) or (
            global_step == config.total_steps
        )
        if do_ckpt:
            payload = checkpoint_payload(global_step, "periodic")
            save_checkpoint(_checkpoint_path(run_dir), payload)
            if config.save_step_checkpoints:
                save_checkpoint(_step_checkpoint_path(run_dir, global_step), payload)

        if global_step % config.log_every_steps == 0 and global_step > 0:
            logger.info(
                "step=%d replay=%d updates=%d loss_q=%.4f loss_pi=%.4f wP=%.3f psiQ=%.3f fallback=%.3f",
                global_step,
                replay.size,
                total_updates,
                last_loss["critic"],
                last_loss["actor"],
                last_lite["lite/mean_w_P"],
                last_lite["lite/psi_q_rank_rate"],
                last_lite["lite/q_candidate_fallback_rate"],
            )

    partial_assignment_window = assignment_diagnostics.flush_partial()
    if partial_assignment_window is not None:
        assignment_diagnostics_writer.write(partial_assignment_window)
        final_payload = checkpoint_payload(global_step, "periodic")
        save_checkpoint(_checkpoint_path(run_dir), final_payload)
        if config.save_step_checkpoints:
            save_checkpoint(
                _step_checkpoint_path(run_dir, global_step), final_payload
            )

    runtime_total_sec = float(time.perf_counter() - wall_start)
    summary = {
        "run_dir": str(run_dir),
        "method": config.method,
        "total_steps": config.total_steps,
        "episodes": episode_idx,
        "total_updates": total_updates,
        "support_assignment_mode": config.support_assignment_mode,
        "assignment_seed": config.seeds.assignment_seed,
        "assignment_diagnostic_window_updates": (
            config.assignment_diagnostic_window_updates
        ),
        "assignment_diagnostic_windows": assignment_diagnostics.window_index,
        "assignment_diagnostic_last_update": assignment_diagnostics.last_update,
        "best_eval_success": best_eval_success,
        "best_eval_selection_success": best_eval_selection_success,
        "best_eval_goal_success": best_eval_goal_success,
        "best_eval_env_success": best_eval_env_success,
        "best_eval_return": best_eval_return,
        "best_eval_step": best_eval_step,
        "selection_metric": selection_metric,
        "final_replay_size": replay.size,
        "final_losses": last_loss,
        "final_lite_metrics": last_lite,
        "final_eval_return": last_eval_metrics.get("eval_return_mean", float("nan")),
        "final_eval_success": last_eval_metrics.get("eval_success_mean", float("nan")),
        "final_eval_goal_success": last_eval_metrics.get("eval_goal_success_mean", float("nan")),
        "final_eval_env_success": last_eval_metrics.get("eval_env_success_mean", float("nan")),
        "final_eval_goal_success_ever": last_eval_metrics.get("eval_goal_success_ever_mean", float("nan")),
        "final_eval_env_success_ever": last_eval_metrics.get("eval_env_success_ever_mean", float("nan")),
        "final_eval_goal_success_final": last_eval_metrics.get("eval_goal_success_final_mean", float("nan")),
        "final_eval_env_success_final": last_eval_metrics.get("eval_env_success_final_mean", float("nan")),
        "eval_AUC_success": _auc_success(eval_history_env),
        "first_hit_0.25": _first_hit(eval_history_env, 0.25),
        "first_hit_0.50": _first_hit(eval_history_env, 0.50),
        "first_hit_0.75": _first_hit(eval_history_env, 0.75),
        "first_hit_0.90": _first_hit(eval_history_env, 0.90),
        "runtime_total_sec": runtime_total_sec,
        "final_steps_per_sec": float(global_step) / max(runtime_total_sec, 1e-8),
        "posthoc_correlation_metrics_online_computed": False,
    }
    if config.task_name == "push_t":
        summary.update(
            {
                "final_pushT_obj_goal_xy_dist_mean": last_eval_metrics.get(
                    "pushT/obj_goal_xy_dist_mean", float("nan")
                ),
                "final_pushT_obj_goal_rot_err_mean": last_eval_metrics.get(
                    "pushT/obj_goal_rot_err_mean", float("nan")
                ),
                "final_pushT_intersection_ratio_mean": last_eval_metrics.get(
                    "pushT/intersection_ratio_mean", float("nan")
                ),
                "final_pushT_contact_like_rate": last_eval_metrics.get("pushT/contact_like_rate", float("nan")),
                "final_pushT_pos_progress_rate": last_eval_metrics.get("pushT/pos_progress_rate", float("nan")),
                "final_pushT_rot_progress_rate": last_eval_metrics.get("pushT/rot_progress_rate", float("nan")),
            }
        )
    write_json(run_dir / "summary.json", summary)
    csv_writer.close()
    assignment_diagnostics_writer.close()
    jsonl_writer.close()
    train_env.close()
    eval_env.close()
    logger.info("finished run at %s", run_dir)
    return run_dir


def _empty_lite_metrics(phase_names: tuple[str, ...] = ("approach", "grasp", "transport", "release_place")) -> Dict[str, float]:
    metrics = {
        "lite/mean_G_sup": 0.0,
        "lite/positive_G_sup_rate": 0.0,
        "lite/mean_kappa": 0.0,
        "lite/mean_w_P": 1.0,
        "lite/max_w_P": 1.0,
        "lite/std_w_P": 0.0,
        "lite/entropy_w_P": 0.0,
        "lite/ESS_w": 0.0,
        "lite/ESS_w_normalized": 0.0,
        "lite/support_available_rate": 0.0,
        "lite/psi_q_rank_rate": 0.0,
        "lite/q_candidate_fallback_rate": 1.0,
        "lite/psi_A_policy_rate": 0.0,
        "lite/psi_A_query_rate": 0.0,
        "query/context_count_eligible_rate": 0.0,
        "query/support_positive_rate": 0.0,
        "query/query_bin_present_given_context_rate": np.nan,
        "query/high_weight_count": 0.0,
        "query/raw_weight_mean": 1.0,
        "query/raw_weight_std": 0.0,
        "query/raw_weight_ESS": 0.0,
        "query/normalized_weight_mean": 1.0,
        "query/normalized_weight_std": 0.0,
        "query/normalized_weight_ESS": 0.0,
        "query/query_bin_matches_current_policy_rate": np.nan,
        "query/query_bin_matches_replay_action_rate": np.nan,
        "lite/mean_len_A_Q_sup": 0.0,
        "lite/mean_len_A_Q_replay_local": 0.0,
        "lite/local_support_count_mean": 0.0,
        "lite/local_support_count_p50": 0.0,
        "lite/local_support_count_p90": 0.0,
        "lite/mean_num_coarse_candidates": 0.0,
        "lite/mean_num_scanned_candidates": 0.0,
        "lite/local_scan_truncated_rate": 0.0,
        "lite/mean_Q_imp_minus_Q_policy": 0.0,
        "lite/unrestricted_gap_mean": 0.0,
        "lite/gap_ready": 0.0,
        "lite/gap_tau": 0.0,
        "lite/gap_max": 0.0,
        "time/local_context_lookup": 0.0,
        "time/candidate_construction": 0.0,
        "time/local_context": 0.0,
        "time/q_policy_eval": 0.0,
        "time/q_candidate_eval": 0.0,
        "time/weight_compute": 0.0,
        "time/actor_critic_update": 0.0,
        "time/numba_support_scan": 0.0,
        "time_local_context_lookup": 0.0,
        "time_candidate_construction": 0.0,
        "time_q_policy_eval": 0.0,
        "time_q_candidate_eval": 0.0,
        "time_weight_computation": 0.0,
        "time_actor_critic_update": 0.0,
        "runtime/steps_per_sec": 0.0,
        "runtime/total_sec": 0.0,
        "runtime/overhead_vs_B0": np.nan,
        "runtime/support_cache_hit_rate": np.nan,
        "runtime/support_cache_miss_rate": np.nan,
        "runtime/batch_query_unique_rate": np.nan,
        "runtime/batch_query_coalescing_saving_rate": np.nan,
        "runtime/coarse_query_unique_rate": np.nan,
        "runtime/local_scan_cache_hit_rate": np.nan,
        "runtime/local_scan_cache_miss_rate": np.nan,
        "runtime/full_context_scan_rate": np.nan,
        "runtime/exact_negative_short_circuit_rate": np.nan,
        "runtime/count_short_circuit_rate": np.nan,
        "runtime/threshold_short_circuit_rate": np.nan,
        "runtime/coarse_count_short_circuit_rate": np.nan,
        "runtime/coarse_support_size_short_circuit_rate": np.nan,
        "runtime/scanned_count_short_circuit_rate": np.nan,
        "runtime/coarse_action_bin_count_lookup_rate": np.nan,
        "runtime/support_cache_attempt_rate": np.nan,
        "runtime/support_context_cache_size": np.nan,
        "runtime/local_scan_cache_attempt_rate": np.nan,
        "runtime/local_scan_cache_size": np.nan,
        "runtime/full_context_filter_count_mean": np.nan,
        "runtime/numba_support_scan_enabled": np.nan,
        "runtime/numba_scanner_warmed": np.nan,
        "runtime/numba_support_scan_fallback_rate": np.nan,
        "runtime/numba_support_queries": np.nan,
        "runtime/predicate_early_exit_rate": np.nan,
        "runtime/predicate_scanned_count_mean": np.nan,
        "runtime/diagnostic_audit_rate": np.nan,
        "runtime/audit_len_A_Q_local_abs_diff_mean": np.nan,
        "runtime/audit_len_A_Q_sup_abs_diff_mean": np.nan,
        "runtime/audit_psi_A_policy_mismatch_rate": np.nan,
        "runtime/audit_psi_A_query_mismatch_rate": np.nan,
        "runtime/context_count_eligible_rate": np.nan,
        "mean_w_P_reference": np.nan,
        "reference_high_weight_rate": np.nan,
        "assigned_high_weight_rate": np.nan,
        "support_weight_alignment_rate": np.nan,
        "support_cache_hit_rate": np.nan,
        "short_circuit_rate": np.nan,
        "lite/mean_w_P_reference": np.nan,
        "lite/reference_high_weight_rate": np.nan,
        "lite/assigned_high_weight_rate": np.nan,
        "lite/support_weight_alignment_rate": np.nan,
        "lite/support_cache_hit_rate": np.nan,
        "lite/short_circuit_rate": np.nan,
        "lite/runtime_opt_exact_path": 0.0,
        "td_error/abs_mean": np.nan,
        "td_error/abs_p90": np.nan,
        "td_error/weight_mean": np.nan,
        "td_error/weight_max": np.nan,
        "td_error/weight_entropy": np.nan,
        "td_error/weight_ESS": np.nan,
        "per/priority_entropy": np.nan,
        "per/priority_ESS": np.nan,
        "per/weight_mean": np.nan,
        "per/weight_max": np.nan,
        "per/weight_entropy": np.nan,
        "per/weight_ESS": np.nan,
        "b2/unrestricted_gap_mean": 0.0,
        "b2/unrestricted_gap_p95": 0.0,
        "b2/candidate_action_norm_mean": 0.0,
        "b2/action_delta_norm_mean": 0.0,
        "b2/q_imp_minus_q_policy_mean": 0.0,
        "b2/high_gap_rate": 0.0,
        "b2/gap_to_pos_progress_corr": np.nan,
        "b2/gap_to_rot_progress_corr": np.nan,
        "b2/high_gap_bad_progress_rate": np.nan,
        "b3/support_available_rate": 0.0,
        "b3/local_support_count_mean": 0.0,
        "b3/local_support_count_p50": 0.0,
        "b3/local_support_count_p90": 0.0,
        "b3/support_to_pos_progress_corr": np.nan,
        "b3/support_to_rot_progress_corr": np.nan,
        "b3/support_to_success_corr": np.nan,
        "b3/support_to_td_error_corr": np.nan,
        "b4/G_sup_mean": 0.0,
        "b4/G_sup_positive_rate": 0.0,
        "b4/support_candidate_count_mean": 0.0,
        "b4/support_candidate_count_p50": 0.0,
        "b4/support_candidate_count_p90": 0.0,
        "b4/fallback_rate": 1.0,
        "b4/local_scan_truncated_rate": 0.0,
        "b4/B2_gap_minus_B4_gap": np.nan,
        "b4/unsupported_gap_rate": np.nan,
    }
    for phase_name in phase_names:
        metrics[f"lite/phase_{phase_name}_mean_w_P"] = 0.0
        metrics[f"lite/phase_{phase_name}_fallback_rate"] = 0.0
        metrics[f"lite/phase_{phase_name}_psi_q_rank_rate"] = 0.0
        metrics[f"lite/phase_{phase_name}_positive_G_sup_rate"] = 0.0
        metrics[f"lite/phase_{phase_name}_count_rate"] = 0.0
        metrics[f"query/support_positive_rate_phase_{phase_name}"] = 0.0
        metrics[f"b3/support_by_phase_{phase_name}"] = 0.0
        metrics[f"b3/mean_w_P_by_phase_{phase_name}"] = 0.0
        metrics[f"b3/fallback_by_phase_{phase_name}"] = 0.0
    metrics["lite/slide_mean_obj_speed"] = 0.0
    metrics["lite/slide_mean_vel_align"] = 0.0
    metrics["lite/slide_phase_distribution_approach"] = 0.0
    metrics["lite/slide_phase_distribution_strike"] = 0.0
    metrics["lite/slide_phase_distribution_slide"] = 0.0
    metrics["lite/slide_phase_distribution_near_goal"] = 0.0
    return metrics


def _lite_metrics_from_weight_batch(
    wb: Any,
    phase_names: tuple[str, ...] = ("approach", "grasp", "transport", "release_place"),
) -> Dict[str, float]:
    metrics = {
        "lite/mean_G_sup": _mean(wb.g_sup),
        "lite/positive_G_sup_rate": float(np.mean(wb.g_sup > 0.0)),
        "lite/mean_kappa": _mean(wb.kappa),
        "lite/mean_w_P": _mean(wb.w_p_raw),
        "lite/max_w_P": float(np.max(wb.w_p_raw)) if wb.w_p_raw.size else 1.0,
        "lite/std_w_P": float(np.std(wb.w_p_raw)) if wb.w_p_raw.size else 0.0,
        "lite/entropy_w_P": _entropy_weight(wb.w_p_raw, 1e-8),
        "lite/ESS_w": _ess_weight(wb.w_p_raw, 1e-8),
        "lite/ESS_w_normalized": _ess_weight(wb.w_p_raw, 1e-8) / max(1, int(wb.w_p_raw.size)),
        "lite/support_available_rate": _mean(wb.psi_q_rank),
        "lite/psi_q_rank_rate": _mean(wb.psi_q_rank),
        "lite/q_candidate_fallback_rate": _mean(wb.q_candidate_fallback),
        "lite/psi_A_policy_rate": _mean(wb.psi_a_policy),
        "lite/psi_A_query_rate": _mean(wb.psi_a_query),
        "lite/mean_len_A_Q_sup": _mean(wb.len_a_q_sup),
        "lite/mean_len_A_Q_replay_local": _mean(wb.len_a_q_local),
        "lite/local_support_count_mean": _mean(wb.len_a_q_local),
        "lite/local_support_count_p50": _nanpercentile(wb.len_a_q_local, 50.0),
        "lite/local_support_count_p90": _nanpercentile(wb.len_a_q_local, 90.0),
        "lite/mean_num_coarse_candidates": _mean(wb.num_coarse_candidates),
        "lite/mean_num_scanned_candidates": _mean(wb.num_scanned_candidates),
        "lite/local_scan_truncated_rate": _mean(wb.local_scan_truncated),
        "lite/mean_Q_imp_minus_Q_policy": _mean(wb.q_imp_minus_q_policy),
        "lite/unrestricted_gap_mean": _mean(wb.unrestricted_gap),
        "lite/gap_ready": float(wb.gap_ready),
        "lite/gap_tau": float(wb.gap_tau),
        "lite/gap_max": float(wb.gap_max),
        "b2/unrestricted_gap_mean": _mean(wb.unrestricted_gap),
        "b2/unrestricted_gap_p95": _nanpercentile(wb.unrestricted_gap, 95.0),
        "b2/candidate_action_norm_mean": float(getattr(wb, "extra_metrics", {}).get("b2/candidate_action_norm_mean", 0.0)),
        "b2/action_delta_norm_mean": float(getattr(wb, "extra_metrics", {}).get("b2/action_delta_norm_mean", 0.0)),
        "b2/q_imp_minus_q_policy_mean": _mean(wb.q_imp_minus_q_policy),
        "b2/high_gap_rate": float(np.mean(wb.unrestricted_gap > max(float(wb.gap_tau), 0.0))) if wb.unrestricted_gap.size else 0.0,
        "b2/gap_to_pos_progress_corr": np.nan,
        "b2/gap_to_rot_progress_corr": np.nan,
        "b2/high_gap_bad_progress_rate": np.nan,
        "b3/support_available_rate": _mean(wb.psi_q_rank),
        "b3/local_support_count_mean": _mean(wb.len_a_q_local),
        "b3/local_support_count_p50": _nanpercentile(wb.len_a_q_local, 50.0),
        "b3/local_support_count_p90": _nanpercentile(wb.len_a_q_local, 90.0),
        "b3/support_to_pos_progress_corr": np.nan,
        "b3/support_to_rot_progress_corr": np.nan,
        "b3/support_to_success_corr": np.nan,
        "b3/support_to_td_error_corr": np.nan,
        "b4/G_sup_mean": _mean(wb.g_sup),
        "b4/G_sup_positive_rate": float(np.mean(wb.g_sup > 0.0)) if wb.g_sup.size else 0.0,
        "b4/support_candidate_count_mean": _mean(wb.len_a_q_sup),
        "b4/support_candidate_count_p50": _nanpercentile(wb.len_a_q_sup, 50.0),
        "b4/support_candidate_count_p90": _nanpercentile(wb.len_a_q_sup, 90.0),
        "b4/fallback_rate": _mean(wb.q_candidate_fallback),
        "b4/local_scan_truncated_rate": _mean(wb.local_scan_truncated),
        "b4/B2_gap_minus_B4_gap": np.nan,
        "b4/unsupported_gap_rate": np.nan,
        "time/local_context_lookup": float(wb.timing.get("local_context_lookup", 0.0)),
        "time/candidate_construction": float(wb.timing.get("candidate_construction", 0.0)),
        "time/local_context": float(wb.timing.get("local_context", 0.0)),
        "time/q_policy_eval": float(wb.timing.get("q_policy_eval", 0.0)),
        "time/q_candidate_eval": float(wb.timing.get("q_candidate_eval", 0.0)),
        "time/weight_compute": float(wb.timing.get("weight_compute", 0.0)),
        "time/actor_critic_update": 0.0,
        "time_local_context_lookup": float(wb.timing.get("local_context_lookup", 0.0)),
        "time_candidate_construction": float(wb.timing.get("candidate_construction", 0.0)),
        "time_q_policy_eval": float(wb.timing.get("q_policy_eval", 0.0)),
        "time_q_candidate_eval": float(wb.timing.get("q_candidate_eval", 0.0)),
        "time_weight_computation": float(wb.timing.get("weight_computation", wb.timing.get("weight_compute", 0.0))),
        "time_actor_critic_update": 0.0,
    }
    phases = getattr(wb, "phase", np.zeros_like(wb.w_p_raw, dtype=np.int64))
    for phase_id, phase_name in enumerate(phase_names):
        mask = phases == phase_id
        if np.any(mask):
            metrics[f"lite/phase_{phase_name}_mean_w_P"] = float(np.mean(wb.w_p_raw[mask]))
            metrics[f"lite/phase_{phase_name}_fallback_rate"] = float(np.mean(wb.q_candidate_fallback[mask]))
            metrics[f"lite/phase_{phase_name}_psi_q_rank_rate"] = float(np.mean(wb.psi_q_rank[mask]))
            metrics[f"lite/phase_{phase_name}_positive_G_sup_rate"] = float(np.mean(wb.g_sup[mask] > 0.0))
            metrics[f"lite/phase_{phase_name}_count_rate"] = float(np.mean(mask))
            metrics[f"query/support_positive_rate_phase_{phase_name}"] = float(np.mean(wb.psi_q_rank[mask]))
            metrics[f"b3/support_by_phase_{phase_name}"] = float(np.mean(wb.psi_q_rank[mask]))
            metrics[f"b3/mean_w_P_by_phase_{phase_name}"] = float(np.mean(wb.w_p_raw[mask]))
            metrics[f"b3/fallback_by_phase_{phase_name}"] = float(np.mean(wb.q_candidate_fallback[mask]))
        else:
            metrics[f"lite/phase_{phase_name}_mean_w_P"] = 0.0
            metrics[f"lite/phase_{phase_name}_fallback_rate"] = 0.0
            metrics[f"lite/phase_{phase_name}_psi_q_rank_rate"] = 0.0
            metrics[f"lite/phase_{phase_name}_positive_G_sup_rate"] = 0.0
            metrics[f"lite/phase_{phase_name}_count_rate"] = 0.0
            metrics[f"query/support_positive_rate_phase_{phase_name}"] = 0.0
            metrics[f"b3/support_by_phase_{phase_name}"] = 0.0
            metrics[f"b3/mean_w_P_by_phase_{phase_name}"] = 0.0
            metrics[f"b3/fallback_by_phase_{phase_name}"] = 0.0
    for key, value in getattr(wb, "extra_metrics", {}).items():
        metrics[key] = float(value)
    return metrics


def _add_runtime(row: Dict[str, Any], wall_start: float, step: int) -> None:
    total_sec = max(0.0, float(time.perf_counter() - wall_start))
    row["runtime/total_sec"] = total_sec
    row["runtime/steps_per_sec"] = float(step) / max(total_sec, 1e-8)
    row["runtime/overhead_vs_B0"] = ""


def _metric_row(
    step: int,
    episode: int,
    ep_return: float,
    ep_success: float,
    ep_len: int,
    replay_size: int,
    her_ratio: float,
    loss: Dict[str, float],
    lite: Dict[str, float],
    config: LiteConfig,
) -> Dict[str, Any]:
    return {
        "step": step,
        "episode": episode,
        "train/episode_return": ep_return,
        "train/episode_success": ep_success,
        "train/episode_len": ep_len,
        "train/replay_size": replay_size,
        "train/her_relabel_ratio": her_ratio,
        "config/lambda_support": config.lambda_support,
        "config/weight_scope": config.weight_scope,
        "config/support_query_mode": config.support_query_mode,
        "config/support_assignment_mode": config.support_assignment_mode,
        "loss/critic": loss["critic"],
        "loss/actor": loss["actor"],
        "loss/td_error_abs_mean": loss.get("td_error_abs_mean", 0.0),
        "loss/td_error_abs_p90": loss.get("td_error_abs_p90", 0.0),
        "value/q_mean": loss["q_mean"],
        "value/target_mean": loss["target_mean"],
        "critic/q_policy_mean": loss.get("q_mean", 0.0),
        "critic/q_policy_std": loss.get("q_std", 0.0),
        "critic/q_target_mean": loss.get("target_mean", 0.0),
        "critic/q_target_std": loss.get("target_std", 0.0),
        "critic/q_abs_mean": loss.get("q_abs_mean", 0.0),
        "critic/q_abs_max": loss.get("q_abs_max", 0.0),
        **lite,
        "eval/return_mean": "",
        "eval/success_mean": "",
        "eval/goal_success_mean": "",
        "eval/env_success_mean": "",
        "eval/goal_success_ever_mean": "",
        "eval/goal_success_ever_std": "",
        "eval/env_success_ever_mean": "",
        "eval/env_success_ever_std": "",
        "eval/goal_success_final_mean": "",
        "eval/goal_success_final_std": "",
        "eval/env_success_final_mean": "",
        "eval/env_success_final_std": "",
        "eval/episode_length_mean": "",
        "eval/final_success": "",
        "eval/best_success": "",
        "eval/AUC_success": "",
        "eval/first_hit_0.25": "",
        "eval/first_hit_0.50": "",
        "eval/first_hit_0.75": "",
        "eval/first_hit_0.90": "",
    }
