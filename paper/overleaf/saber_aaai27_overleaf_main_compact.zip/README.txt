SABER AAAI-27 Overleaf package

Upload this ZIP directly to Overleaf and use main.tex as the main document.
Compiler: pdfLaTeX
Bibliography tool: BibTeX

This package was assembled from paper/main_compact.tex at source commit
3167255542e81881533b13c8cf178f420cdb1483.

The included main_compact.pdf is the reference PDF used to validate the
package. Its SHA-256 digest is:
e5b6b3374a7c5012e154ee71512bc0289935589f07ce136cbc29cf56d57d8c2f

Generated files such as .aux, .bbl, .blg, and .log are intentionally omitted.
